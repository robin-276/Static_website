
// Enhanced script for LINEMARK STATIONERY website
console.log("LINEMARK STATIONERY website loaded successfully");

// ================================
// COLOR CONFIGURATION SECTION
// ================================
// Customize colors for different sections of your website
// Change any color value here and call applyColors() to update the website

const colorConfig = {
    // Header Section Colors
    header: {
        backgroundColor: '#ffffff',
        textColor: '#333333',
        logoColor: '#2563eb',
        taglineColor: '#666666',
        navLinkColor: '#333333',
        navHoverColor: '#2563eb',
        navHoverBackground: '#eff6ff',
        shadowColor: 'rgba(0,0,0,0.1)'
    },
    
    // Hero Section Colors
    hero: {
        backgroundGradient: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        textColor: '#ffffff',
        headingColor: '#ffffff',
        buttonBackground: '#ff6b35',
        buttonHoverBackground: '#e55a2b',
        buttonTextColor: '#ffffff'
    },
    
    // Categories Section Colors
    categories: {
        backgroundColor: '#f8fafc',
        sectionTitleColor: '#1f2937',
        cardBackground: '#ffffff',
        cardTextColor: '#374151',
        cardHoverShadow: 'rgba(0,0,0,0.15)',
        cardShadow: 'rgba(0,0,0,0.05)'
    },
    
    // Office Section Colors
    office: {
        backgroundColor: '#ffffff',
        sectionTitleColor: '#1f2937',
        cardBackground: '#ffffff',
        cardTextColor: '#374151',
        cardHoverShadow: 'rgba(0,0,0,0.15)',
        cardShadow: 'rgba(0,0,0,0.05)'
    },
    
    // Promotional Section Colors
    promo: {
        backgroundColor: '#ffffff',
        blueBannerBackground: 'linear-gradient(45deg, #3b82f6, #1d4ed8)',
        yellowBannerBackground: 'linear-gradient(45deg, #f59e0b, #d97706)',
        textColor: '#ffffff',
        headingColor: '#ffffff'
    },
    
    // Featured Products Section Colors
    featured: {
        backgroundColor: '#f8fafc',
        sectionTitleColor: '#1f2937',
        cardBackground: '#ffffff',
        productNameColor: '#374151',
        ratingColor: '#fbbf24',
        currentPriceColor: '#dc2626',
        originalPriceColor: '#9ca3af',
        cardShadow: 'rgba(0,0,0,0.05)',
        cardHoverShadow: 'rgba(0,0,0,0.15)'
    },
    
    // About Page Colors
    about: {
        backgroundColor: '#ffffff',
        valuesBackground: '#f8fafc',
        headingColor: '#1f2937',
        subHeadingColor: '#374151',
        textColor: '#4b5563',
        valueCardBackground: '#ffffff',
        valueCardShadow: 'rgba(0,0,0,0.05)',
        valueCardHoverShadow: 'rgba(0,0,0,0.15)'
    },
    
    // Contact Page Colors
    contact: {
        backgroundColor: '#ffffff',
        headingColor: '#1f2937',
        textColor: '#4b5563',
        formBackground: '#ffffff',
        inputBorder: '#d1d5db',
        inputFocus: '#2563eb',
        buttonBackground: '#2563eb',
        buttonHoverBackground: '#1d4ed8',
        buttonTextColor: '#ffffff'
    },
    
    // Footer Section Colors
    footer: {
        backgroundColor: '#1f2937',
        textColor: '#ffffff',
        headingColor: '#ffffff',
        linkColor: '#e5e7eb',
        linkHoverColor: '#2563eb',
        bottomBorderColor: '#374151'
    }
};

// Function to apply colors to the website
function applyColors() {
    const root = document.documentElement;
    
    // Apply header colors
    const header = document.querySelector('.main-header');
    if (header) {
        header.style.backgroundColor = colorConfig.header.backgroundColor;
        header.style.boxShadow = `0 2px 10px ${colorConfig.header.shadowColor}`;
    }
    
    const logo = document.querySelector('.logo h1');
    if (logo) logo.style.color = colorConfig.header.logoColor;
    
    const tagline = document.querySelector('.logo .tagline');
    if (tagline) tagline.style.color = colorConfig.header.taglineColor;
    
    // Apply hero colors
    const hero = document.querySelector('.hero-section');
    if (hero) {
        hero.style.background = colorConfig.hero.backgroundGradient;
        hero.style.color = colorConfig.hero.textColor;
    }
    
    const pageHero = document.querySelector('.page-hero');
    if (pageHero) {
        pageHero.style.background = colorConfig.hero.backgroundGradient;
        pageHero.style.color = colorConfig.hero.textColor;
    }
    
    // Apply categories section colors
    const categoriesSection = document.querySelector('.categories-section');
    if (categoriesSection) {
        categoriesSection.style.backgroundColor = colorConfig.categories.backgroundColor;
    }
    
    // Apply office section colors
    const officeSection = document.querySelector('.office-section');
    if (officeSection) {
        officeSection.style.backgroundColor = colorConfig.office.backgroundColor;
    }
    
    // Apply featured section colors
    const featuredSection = document.querySelector('.featured-section');
    if (featuredSection) {
        featuredSection.style.backgroundColor = colorConfig.featured.backgroundColor;
    }
    
    // Apply footer colors
    const footer = document.querySelector('.main-footer');
    if (footer) {
        footer.style.backgroundColor = colorConfig.footer.backgroundColor;
        footer.style.color = colorConfig.footer.textColor;
    }
    
    console.log('Colors applied successfully!');
}

// Function to change specific section colors
function changeSectionColor(section, property, newColor) {
    if (colorConfig[section] && colorConfig[section][property] !== undefined) {
        colorConfig[section][property] = newColor;
        applyColors();
        console.log(`Updated ${section}.${property} to ${newColor}`);
    } else {
        console.error(`Invalid section "${section}" or property "${property}"`);
    }
}

// Function to get current color configuration
function getColorConfig() {
    return colorConfig;
}

// Function to reset colors to default
function resetColorsToDefault() {
    // This would reset to the original configuration
    location.reload();
}

// Examples of how to use the color system:
// changeSectionColor('hero', 'backgroundGradient', 'linear-gradient(135deg, #ff6b35 0%, #f7931e 100%)');
// changeSectionColor('categories', 'backgroundColor', '#e0f2fe');
// changeSectionColor('header', 'logoColor', '#dc2626');

console.log('Color configuration system loaded! Use changeSectionColor() to modify colors.');

// ================================
// FEATURED PRODUCTS CONFIGURATION
// ================================
// Easy management of featured products - organized by rows and columns
// You can add, remove, or modify products here

const featuredProducts = {
    // ROW 1: Premium Writing Instruments
    row1: {
        column1: {
            name: "Premium Fountain Pen",
            image: "assets/images/placeholder.jpg",
            rating: "★★★★★ (12)",
            currentPrice: "Rs. 1,250.00",
            originalPrice: "Rs. 1,500.00",
            alt: "Premium Fountain Pen"
        },
        column2: {
            name: "Designer Notebook Set",
            image: "assets/images/placeholder.jpg",
            rating: "★★★★★ (8)",
            currentPrice: "Rs. 650.00",
            originalPrice: "Rs. 750.00",
            alt: "Designer Notebook"
        },
        column3: {
            name: "Pastel Highlighter Set",
            image: "assets/images/placeholder.jpg",
            rating: "★★★★★ (15)",
            currentPrice: "Rs. 425.00",
            originalPrice: "Rs. 500.00",
            alt: "Highlighter Set"
        }
    },
    
    // ROW 2: Office Essentials
    row2: {
        column1: {
            name: "Scientific Calculator",
            image: "assets/images/placeholder.jpg",
            rating: "★★★★★ (20)",
            currentPrice: "Rs. 890.00",
            originalPrice: "Rs. 1,100.00",
            alt: "Professional Calculator"
        },
        column2: {
            name: "Executive Planner 2024",
            image: "assets/images/placeholder.jpg",
            rating: "★★★★★ (18)",
            currentPrice: "Rs. 1,150.00",
            originalPrice: "Rs. 1,350.00",
            alt: "Executive Diary"
        },
        column3: {
            name: "Premium Sticky Notes Pack",
            image: "assets/images/placeholder.jpg",
            rating: "★★★★★ (25)",
            currentPrice: "Rs. 320.00",
            originalPrice: "Rs. 400.00",
            alt: "Sticky Notes Pack"
        }
    },
    
    // ROW 3: A4 Paper & Supplies
    row3: {
        column1: {
            name: "Premium A4 Paper (500 Sheets)",
            image: "assets/images/placeholder.jpg",
            rating: "★★★★★ (35)",
            currentPrice: "Rs. 280.00",
            originalPrice: "Rs. 320.00",
            alt: "A4 Paper Premium"
        },
        column2: {
            name: "White Out Correction Tape",
            image: "assets/images/placeholder.jpg",
            rating: "★★★★★ (22)",
            currentPrice: "Rs. 85.00",
            originalPrice: "Rs. 110.00",
            alt: "Correction Tape"
        },
        column3: {
            name: "Multi-Pocket File Organizer",
            image: "assets/images/placeholder.jpg",
            rating: "★★★★★ (14)",
            currentPrice: "Rs. 450.00",
            originalPrice: "Rs. 550.00",
            alt: "File Organizer"
        }
    }
};

// ================================
// FEATURED PRODUCTS MANAGEMENT FUNCTIONS
// ================================

// Function to update a specific product
function updateFeaturedProduct(row, column, productData) {
    const rowKey = `row${row}`;
    const columnKey = `column${column}`;
    
    if (featuredProducts[rowKey] && featuredProducts[rowKey][columnKey]) {
        featuredProducts[rowKey][columnKey] = { ...featuredProducts[rowKey][columnKey], ...productData };
        renderFeaturedProducts();
        console.log(`Updated product at Row ${row}, Column ${column}`);
    } else {
        console.error(`Invalid row ${row} or column ${column}`);
    }
}

// Function to add a new row of products
function addFeaturedProductRow(rowNumber, productsData) {
    const rowKey = `row${rowNumber}`;
    featuredProducts[rowKey] = productsData;
    renderFeaturedProducts();
    console.log(`Added new row ${rowNumber} with products`);
}

// Function to remove a row
function removeFeaturedProductRow(rowNumber) {
    const rowKey = `row${rowNumber}`;
    if (featuredProducts[rowKey]) {
        delete featuredProducts[rowKey];
        renderFeaturedProducts();
        console.log(`Removed row ${rowNumber}`);
    } else {
        console.error(`Row ${rowNumber} does not exist`);
    }
}

// Function to get product information
function getFeaturedProduct(row, column) {
    const rowKey = `row${row}`;
    const columnKey = `column${column}`;
    
    if (featuredProducts[rowKey] && featuredProducts[rowKey][columnKey]) {
        return featuredProducts[rowKey][columnKey];
    } else {
        console.error(`Product not found at Row ${row}, Column ${column}`);
        return null;
    }
}

// Function to render/update the featured products in the HTML
function renderFeaturedProducts() {
    const featuredGrid = document.querySelector('.featured-grid');
    if (!featuredGrid) return;
    
    // Clear existing products
    featuredGrid.innerHTML = '';
    
    // Generate HTML for each row and column
    Object.keys(featuredProducts).forEach(rowKey => {
        const rowNumber = rowKey.replace('row', '');
        const rowData = featuredProducts[rowKey];
        
        // Add a comment for the row
        const rowComment = document.createComment(` ROW ${rowNumber} `);
        featuredGrid.appendChild(rowComment);
        
        Object.keys(rowData).forEach(columnKey => {
            const columnNumber = columnKey.replace('column', '');
            const product = rowData[columnKey];
            
            const productCard = document.createElement('div');
            productCard.className = 'product-card';
            productCard.setAttribute('data-row', rowNumber);
            productCard.setAttribute('data-column', columnNumber);
            
            productCard.innerHTML = `
                <div class="product-image">
                    <img src="${product.image}" alt="${product.alt}">
                </div>
                <h3>${product.name}</h3>
                <div class="product-rating">${product.rating}</div>
                <div class="product-price">
                    <span class="current-price">${product.currentPrice}</span>
                    <span class="original-price">${product.originalPrice}</span>
                </div>
            `;
            
            featuredGrid.appendChild(productCard);
        });
    });
    
    console.log('Featured products rendered successfully!');
}

// Examples of how to use the featured products system:
// updateFeaturedProduct(1, 2, { name: "New Product Name", currentPrice: "Rs. 999.00" });
// addFeaturedProductRow(4, { column1: {...}, column2: {...}, column3: {...} });
// removeFeaturedProductRow(3);
// getFeaturedProduct(2, 1);

console.log('Featured Products Management System loaded!');

// Smooth scrolling for anchor links
document.addEventListener('DOMContentLoaded', function() {
    // Initialize color system
    applyColors();
    // Add smooth scrolling to all links
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                targetSection.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Add animation on scroll for category cards
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe category cards and product cards
    const cards = document.querySelectorAll('.category-card, .office-card, .product-card');
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });

    // Form submission handling
    const contactForm = document.querySelector('.contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(this);
            const name = formData.get('name');
            const email = formData.get('email');
            const subject = formData.get('subject');
            const message = formData.get('message');
            
            // Simple validation
            if (!name || !email || !subject || !message) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Simulate form submission
            alert(`Thank you, ${name}! Your message has been received. We'll get back to you soon.`);
            
            // Reset form
            this.reset();
        });
    }

    // Add hover effects to navigation
    const navLinks = document.querySelectorAll('.main-nav a');
    navLinks.forEach(link => {
        link.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });
        
        link.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Add click animation to buttons
    const buttons = document.querySelectorAll('.cta-button, .promo-button, .submit-button');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Create ripple effect
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.cssText = `
                position: absolute;
                border-radius: 50%;
                background: rgba(255,255,255,0.6);
                transform: scale(0);
                animation: ripple 0.6s linear;
                left: ${x}px;
                top: ${y}px;
                width: ${size}px;
                height: ${size}px;
                pointer-events: none;
            `;
            
            this.style.position = 'relative';
            this.style.overflow = 'hidden';
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });

    // Add CSS for ripple animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);

   // Add smooth fade + zoom animation for images
const images = document.querySelectorAll('img');

images.forEach(img => {
    // Start with hidden and slightly smaller
    img.style.opacity = '0';
    img.style.transform = 'scale(0.95)';
    img.style.transition = 'opacity 3s ease-out, transform 1s ease-out';

    // If already loaded, show immediately
    if (img.complete) {
        requestAnimationFrame(() => {
            img.style.opacity = '1';
            img.style.transform = 'scale(1)';
        });
    } else {
        img.addEventListener('load', () => {
            // Small delay helps make it feel smoother
            requestAnimationFrame(() => {
                img.style.opacity = '1';
                img.style.transform = 'scale(1)';
            });
        });
    }
});



    // const images = document.querySelectorAll('img');
    // images.forEach(img => {
    //     img.addEventListener('load', function() {
    //         this.style.opacity = '1';
    //     });
        
    //     // Set initial opacity
    //     img.style.opacity = '0.5';
    //     img.style.transition = 'opacity 0.3s ease';
    // });

    // Newsletter signup simulation (if you add this feature later)
    window.subscribeNewsletter = function(email) {
        if (email && email.includes('@')) {
            alert(`Thank you for subscribing with ${email}! You'll receive updates about our latest stationery products.`);
            return true;
        } else {
            alert('Please enter a valid email address.');
            return false;
        }
    };

    console.log("All interactive features loaded successfully!");
});

// Add a simple dark mode toggle (optional feature)
window.toggleDarkMode = function() {
    document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', document.body.classList.contains('dark-mode'));
};

// Load dark mode preference on page load
if (localStorage.getItem('darkMode') === 'true') {
    document.body.classList.add('dark-mode');
}
